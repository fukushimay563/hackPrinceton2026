"use client";
import { useRouter } from "next/navigation";
import { ArrowRight, CreditCard, FileText, MessageCircle, ShieldCheck, Sparkles, Wallet } from "lucide-react";
import { Logo } from "@/components/AppShell";
import { Button, Card } from "@/components/ui";
import { useApp } from "@/lib/store";
import { simulate } from "@/lib/finance/credit";
import { computeTax } from "@/lib/finance/tax2025";
import { computePaycheck } from "@/lib/finance/paycheck";
import { MAYA_CARD, MAYA_PAYCHECK, MAYA_TAX } from "@/lib/demo/maya";
import { durationLong, usd } from "@/lib/format";

const mayaPay = computePaycheck(MAYA_PAYCHECK);
const mayaMin = simulate(MAYA_CARD, "minimum");
const mayaTax = computeTax(MAYA_TAX);

const FEATURES = [
  { icon: Wallet, title: "First paycheck", body: "See exactly where gross pay goes — taxes, FICA, and what actually lands in your account." },
  { icon: CreditCard, title: "Credit card simulator", body: "Drag a slider and watch interest, payoff time, and utilization change in real time." },
  { icon: FileText, title: "Taxes with the fewest questions", body: "Add your W-2 and the assistant asks only what it can't read from it, with 2025 IRS rules and sources for every number." },
  { icon: MessageCircle, title: "AI tutor that knows your numbers", body: "Ask “why so much interest?” and get your actual math, with IRS and CFPB citations." },
];

export default function Home() {
  const router = useRouter();
  const { loadDemo, startFresh } = useApp();

  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5">
        <Logo />
        <Button
          variant="secondary"
          onClick={() => {
            loadDemo();
            router.push("/paycheck");
          }}
        >
          Try demo
        </Button>
      </header>

      <main className="mx-auto max-w-6xl px-4">
        <section className="grid items-center gap-10 py-10 md:grid-cols-[1.1fr_1fr] md:py-16">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-line bg-white px-3 py-1 text-xs font-semibold text-ink-2">
              <Sparkles size={14} className="text-brand" /> For your first paycheck, first card, first tax return
            </div>
            <h1 className="mt-5 text-4xl leading-[1.05] font-semibold tracking-tight text-ink sm:text-6xl">
              Money gets real fast.
              <br />
              <span className="text-brand">Understand it first.</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg text-ink-2">
              FirstFunds walks you through what happens to your paycheck, what your credit card really costs, and how
              your first tax return works, with an AI tutor that explains your own numbers.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button
                className="px-5 py-3 text-base"
                onClick={() => {
                  loadDemo();
                  router.push("/paycheck");
                }}
              >
                <Sparkles size={18} /> Try Maya&apos;s demo journey
              </Button>
              <Button
                variant="secondary"
                className="px-5 py-3 text-base"
                onClick={() => {
                  startFresh("You");
                  router.push("/paycheck");
                }}
              >
                Use my own numbers <ArrowRight size={18} />
              </Button>
            </div>
            <button
              onClick={() => router.push("/taxes")}
              className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-brand hover:underline"
            >
              <FileText size={16} /> Just here for taxes? File your 2025 return in about 3 minutes <ArrowRight size={14} />
            </button>
            <p className="mt-3 flex items-center gap-2 text-sm text-ink-3">
              <ShieldCheck size={16} /> No sign-up. Nothing is saved after you close the tab.
            </p>
          </div>

          <Card className="relative overflow-hidden">
            <div className="absolute -top-20 -right-20 h-56 w-56 rounded-full bg-mint/40 blur-3xl" />
            <div className="relative">
              <div className="flex items-center gap-3">
                <div className="grid h-11 w-11 place-items-center rounded-full bg-brand-soft text-lg font-bold text-brand-2">M</div>
                <div>
                  <div className="font-semibold">Maya, 20</div>
                  <div className="text-sm text-ink-3">Junior marketing assistant · first credit card</div>
                </div>
              </div>
              <dl className="mt-6 grid grid-cols-2 gap-4">
                <div className="rounded-xl bg-paper p-4">
                  <dt className="text-xs text-ink-3">Gross paycheck</dt>
                  <dd className="num text-xl font-semibold">{usd(mayaPay.gross)}</dd>
                </div>
                <div className="rounded-xl bg-paper p-4">
                  <dt className="text-xs text-ink-3">Take-home</dt>
                  <dd className="num text-xl font-semibold text-brand">{usd(mayaPay.net, true)}</dd>
                </div>
                <div className="col-span-2 rounded-xl bg-debt-soft p-4">
                  <dt className="text-xs text-debt">$600 on her card, minimum payments only</dt>
                  <dd className="num mt-1 text-xl font-semibold text-debt">
                    {durationLong(mayaMin.months)} · {usd(mayaMin.totalInterest)} interest
                  </dd>
                </div>
                <div className="col-span-2 rounded-xl bg-brand-soft p-4">
                  <dt className="text-xs text-brand-2">2025 tax return estimate</dt>
                  <dd className="num mt-1 text-xl font-semibold text-brand-2">{usd(mayaTax.refund)} refund</dd>
                </div>
              </dl>
            </div>
          </Card>
        </section>

        <section className="grid gap-4 pb-16 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f, i) => (
            <Card key={f.title} className="p-5">
              <div className="flex items-center justify-between">
                <f.icon size={22} className="text-brand" />
                <span className="text-xs font-bold text-ink-3">0{i + 1}</span>
              </div>
              <h2 className="mt-4 font-semibold">{f.title}</h2>
              <p className="mt-1 text-sm text-ink-2">{f.body}</p>
            </Card>
          ))}
        </section>
      </main>
      <footer className="mx-auto max-w-6xl px-4 pb-10 text-xs text-ink-3">
        Educational estimates only — not financial, legal, or tax advice. FirstFunds does not file tax returns.
      </footer>
    </div>
  );
}
