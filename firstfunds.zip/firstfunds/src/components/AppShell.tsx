"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { ArrowLeft, ArrowRight, CreditCard, FileText, MessageCircle, Sparkles, Wallet } from "lucide-react";
import type { ReactNode } from "react";
import { useApp } from "@/lib/store";
import { Button, Card, cn } from "./ui";
import { TutorPanel } from "./TutorPanel";

export const STEPS = [
  { href: "/paycheck", label: "Paycheck", icon: Wallet },
  { href: "/credit", label: "Credit card", icon: CreditCard },
  { href: "/taxes", label: "Taxes", icon: FileText },
  { href: "/tutor", label: "AI tutor", icon: MessageCircle },
];

export function Logo() {
  return (
    <Link href="/" className="flex items-center gap-2 font-semibold tracking-tight text-ink">
      <span className="grid h-8 w-8 place-items-center rounded-lg bg-ink text-sm font-bold text-mint">F</span>
      <span>FirstFunds</span>
    </Link>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const { profile, setTutorOpen, loadDemo } = useApp();
  const idx = STEPS.findIndex((s) => path.startsWith(s.href));
  const prev = idx > 0 ? STEPS[idx - 1] : null;
  const next = idx >= 0 && idx < STEPS.length - 1 ? STEPS[idx + 1] : null;

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 border-b border-line bg-paper/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
          <Logo />
          <nav aria-label="Journey" className="hidden items-center gap-1 md:flex">
            {STEPS.map((s, i) => {
              const active = i === idx;
              const done = idx > i;
              const Icon = s.icon;
              return (
                <Link
                  key={s.href}
                  href={s.href}
                  aria-current={active ? "step" : undefined}
                  className={cn(
                    "flex items-center gap-2 rounded-full px-3 py-1.5 text-sm font-medium transition-colors",
                    active ? "bg-ink text-white" : done ? "text-brand hover:bg-black/5" : "text-ink-3 hover:bg-black/5 hover:text-ink",
                  )}
                >
                  <span
                    className={cn(
                      "grid h-5 w-5 place-items-center rounded-full text-[11px] font-bold",
                      active ? "bg-mint text-ink" : done ? "bg-brand-soft text-brand" : "bg-black/5",
                    )}
                  >
                    {i + 1}
                  </span>
                  <Icon size={15} className="hidden lg:block" />
                  {s.label}
                </Link>
              );
            })}
          </nav>
          <div className="flex items-center gap-2">
            {profile && (
              <span className="hidden items-center gap-2 rounded-full border border-line bg-white px-3 py-1 text-sm sm:flex">
                <span className="grid h-6 w-6 place-items-center rounded-full bg-brand-soft text-xs font-bold text-brand-2">
                  {profile.name[0]}
                </span>
                {profile.name}
                {profile.isDemo && <span className="text-xs text-ink-3">· demo</span>}
              </span>
            )}
            {!path.startsWith("/tutor") && (
              <Button variant="primary" onClick={() => setTutorOpen(true)} className="py-2">
                <Sparkles size={16} /> <span className="hidden sm:inline">Ask tutor</span>
              </Button>
            )}
          </div>
        </div>
        {/* Mobile stepper */}
        <nav aria-label="Journey" className="flex gap-1 overflow-x-auto px-4 pb-2 md:hidden">
          {STEPS.map((s, i) => (
            <Link
              key={s.href}
              href={s.href}
              className={cn(
                "shrink-0 rounded-full px-3 py-1 text-xs font-semibold",
                i === idx ? "bg-ink text-white" : "bg-white text-ink-2 border border-line",
              )}
            >
              {i + 1}. {s.label}
            </Link>
          ))}
        </nav>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6 sm:py-10">
        {profile || path.startsWith("/taxes") ? (
          children
        ) : (
          <Card className="mx-auto max-w-lg text-center">
            <h2 className="text-xl font-semibold">Start with a profile</h2>
            <p className="mt-2 text-ink-2">
              Load Maya&apos;s sample journey to explore everything with realistic data. No personal info needed.
            </p>
            <div className="mt-5 flex justify-center gap-2">
              <Button onClick={loadDemo}>
                <Sparkles size={16} /> Try demo
              </Button>
              <Button variant="secondary" onClick={() => router.push("/")}>
                Back home
              </Button>
            </div>
          </Card>
        )}

        {profile && (prev || next) && (
          <div className="mt-10 flex items-center justify-between border-t border-line pt-6">
            {prev ? (
              <Link href={prev.href} className="flex items-center gap-2 text-sm font-medium text-ink-2 hover:text-ink">
                <ArrowLeft size={16} /> {prev.label}
              </Link>
            ) : (
              <span />
            )}
            {next && (
              <Link
                href={next.href}
                className="flex items-center gap-2 rounded-xl bg-brand px-4 py-2.5 text-sm font-semibold text-white hover:bg-brand-2"
              >
                Next: {next.label} <ArrowRight size={16} />
              </Link>
            )}
          </div>
        )}
      </main>
      <footer className="mx-auto max-w-6xl px-4 pb-10 text-xs leading-relaxed text-ink-3">
        Educational estimates only — not financial, legal, or tax advice. FirstFunds does not file tax returns. Nothing is
        saved after you close the tab. <Link href="/methodology" className="underline">How we calculate</Link>
      </footer>
      <TutorPanel />
    </div>
  );
}
