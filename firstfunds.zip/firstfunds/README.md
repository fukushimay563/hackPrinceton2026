# FirstFunds

**Your first paycheck, first credit card, and first tax return, explained.**
An AI-powered financial education platform for students and young adults. HackPrinceton Fall 2026 · Business & Enterprise.

One connected journey: **Paycheck → Credit card simulator → Guided 2025 tax return → AI tutor**. Every step shares the same data, so the tutor can answer *"Why am I paying so much interest if I only spent $600?"* with the user's real APR, balance and payoff math, citing IRS/CFPB sources.

## Quick start

```bash
npm install
cp .env.example .env.local   # optional — the app works fully offline without keys
npm run dev                  # http://localhost:3000
npm test                     # finance + question-minimizer tests (24)
```

Click **Try Maya's demo journey** on the home page to load the whole sample profile.

## Hosted single-page build

```bash
npm run build:static   # → dist-static/index.html (one self-contained file, no server)
```

Same source code as the Next.js app. `next/link` and `next/navigation` are shimmed to hash routes (`#taxes`, `#credit`…). In this build the tutor answers in the browser from the cited corpus, and W-2 photo reading (which needs the server + Gemini key) falls back to typing the two boxes.

## AI Question Minimizer (taxes)

Flow: intro → 3 basic questions → upload → "Checking your documents" → confirm what was read → only the follow-ups documents can't answer → verify → deterministic calculation → human approval.

| Piece | File |
|---|---|
| Shared financial profile (every number keeps its source) | `src/lib/minimizer/types.ts` |
| Question registry: purpose, condition, priority, skip rules | `src/lib/minimizer/registry.ts` |
| Selection + readiness engine, deterministic calc with sources | `src/lib/minimizer/engine.ts` |
| Document checks: duplicates, tax year, missing fields, box 4/6 rates, cross-document conflicts | `src/lib/minimizer/documents.ts` |
| LangGraph workflow (pause points + approval checkpoint) | `src/lib/minimizer/graph.ts` |
| Pause/resume (sessionStorage, tab-only) | `src/lib/minimizer/persist.ts` |
| Screens | `src/components/filing/*` |
| Tests (9 required cases + extras) | `tests/minimizer.test.ts` |

Priority = legally required › affects eligibility/calculation › resolves a conflict › how easily the user can answer. Skipped required questions come back at the end and block "ready" — nothing is ever filled in for the user. "Not sure" blocks readiness with guidance. Any change revokes verification and approval.

Gemini reads uploaded W-2s (`/api/w2-extract`, server only, output schema-validated, document text treated as data). Everything that decides — requirements, validation, scope, arithmetic — is deterministic code. Question explanations are fixed, reviewed text with IRS links (not AI-generated). LangChain is not used yet.

The old 6-step wizard is still available at `/taxes/classic`.

## What works today

| Area | Status |
|---|---|
| Credit card simulator | Balance/limit/APR/payment/new-spending sliders; minimum-payment rule settings; animated balance-over-time chart (minimum vs. your plan vs. 2×); principal-vs-interest chart; utilization meter (no score predictions); month-by-month table; spending limited by the credit limit; "keep spending like this" scenario from transactions |
| Paycheck | Gross → federal withholding estimate, Social Security, Medicare, state → net; donut chart; 50/30/20 budget from take-home |
| Taxes (TY 2025) | 6-step guided flow; W-2 manual entry / from paycheck / Gemini upload; 2025 standard deduction (OBBBA amounts); dependent rule; IRS Tax Table method under $100k; bracket-slice visual; refund/owed; flags for unsupported cases; client-side **1040 review worksheet PDF** (watermarked draft); IRS Free File link |
| AI tutor | Context-aware (reads live numbers from every step); grounded on a cited IRS/CFPB corpus with TF-IDF retrieval; Gemini when `GEMINI_API_KEY` is set; **deterministic offline fallback** so the demo never breaks; slide-over panel on every page + full page |
| Capital One Nessie | `/api/nessie` adapter pulls sandbox purchases if keys are set, otherwise falls back to sample data |
| Privacy | All state is in memory only (no localStorage, no DB). Tutor gets computed numbers only. W-2 uploads processed in memory. |

## Project layout

```
src/lib/finance/      credit.ts · tax2025.ts · paycheck.ts   ← pure, tested calculation engines
src/lib/tutor/        corpus.ts (sources) · retrieve.ts · context.ts · offline.ts · ask.ts
src/lib/demo/maya.ts  demo persona: paycheck, card, transactions, W-2
src/lib/store.ts      shared Zustand state (in-memory)
src/lib/pdf/          1040 review worksheet (pdf-lib, runs in browser)
src/app/(journey)/    paycheck · credit · taxes · tutor pages
src/app/api/          tutor · w2-extract · nessie
tests/                node:test unit tests
```

## Tax figures used (verify before changing)

- Standard deduction 2025: $15,750 single/MFS · $31,500 MFJ · $23,625 HoH (raised by P.L. 119-21)
- Dependent: greater of $1,350 or earned income + $450, capped at the regular amount
- Brackets: Rev. Proc. 2024-40
- Taxable income < $100k → IRS Tax Table (midpoint of $50 rows)

Maya check: $41,600 wages − $15,750 = $25,850 taxable → $2,867 tax (Tax Table) → $3,250 withheld → **$383 refund**.

See `docs/PLAN.md` for the team plan, remaining work and the 2-minute demo script.

*Educational estimates only, not financial, legal or tax advice. FirstFunds does not file tax returns.*
